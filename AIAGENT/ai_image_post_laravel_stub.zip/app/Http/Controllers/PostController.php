<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Intervention\Image\Facades\Image;

class PostController extends Controller
{
    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'image' => 'required|image|mimes:jpeg,png,jpg',
        ]);

        $path = $request->file('image')->store('public/posts');

        $filename = basename($path);
        $imagePath = storage_path('app/public/posts/' . $filename);
        $img = Image::make($imagePath);
        $img->text($request->title, 120, 100, function ($font) {
            $font->file(public_path('fonts/arial.ttf'));
            $font->size(30);
            $font->color('#ffffff');
            $font->align('center');
            $font->valign('top');
        });
        $img->save(storage_path('app/public/posts/ai_' . $filename));

        return response()->json(['image' => 'ai_' . $filename]);
    }
}
